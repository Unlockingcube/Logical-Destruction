﻿using UnityEngine;
using System.Collections;

public class Pivot : MonoBehaviour {
    public float turn;
    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(KeyCode.Q))
        {
            turn+= 1f;
            Quaternion direction = Quaternion.Euler(0, turn, 0);
            transform.rotation = direction;
        }
        if(Input.GetKey(KeyCode.E))
        {
            turn -= 1f;
            Quaternion direction = Quaternion.Euler(0, turn, 0);
            transform.rotation = direction;
        }
    }
}
